package edu.isi.karma.cleaning.Correctness;
/*
 * Test whether different correctnesses can pass the hypotest  
 */
public class HypoTester {

}
