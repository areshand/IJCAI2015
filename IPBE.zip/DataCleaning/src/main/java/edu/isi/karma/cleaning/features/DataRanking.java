package edu.isi.karma.cleaning.features;

import java.util.Vector;

public class DataRanking {
	public Vector<Double> coreVector = new Vector<Double>();
}
