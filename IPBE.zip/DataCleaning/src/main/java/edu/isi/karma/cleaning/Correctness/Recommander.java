package edu.isi.karma.cleaning.Correctness;

import java.util.ArrayList;

/* recommend 
 * 1 the outlier
   2 the points on the boundary
   in the test dataset.
*/
public class Recommander {
	public Recommander()
	{
		
	}
	//
	public ArrayList<String> getOutliers()
	{
		ArrayList<String> res = new ArrayList<String>();
		return res;
	}
	public ArrayList<String> getBoundaryPoints()
	{
		ArrayList<String> res = new ArrayList<String>();
		return res;
	}
}
