package edu.isi.karma.cleaning.features;

public class RecordDistributionFeatures implements Feature {
	public String name = "";
	public String value = "";
	public String tar = "";
	public double score = 0.0;
	@Override
	public String getName() {
		return null;
	}

	@Override
	public double getScore() {
		return 0;
	}

}
